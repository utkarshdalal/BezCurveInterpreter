#include <fstream>
#include <sstream>
#include <vector>
#include <list>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <cmath>
#include <omp.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/time.h>
#endif

#ifdef OSX
#include <GLUT/glut.h>
#include <OpenGL/glu.h>
#else
#include <C:/Users/Utkarsh/Downloads/Documents/CS184/as3-2/GL/glut.h>
#include <GL/glu.h>
#endif

#include <time.h>
#include <math.h>


#include "Curve.h"
#include "Point.h"
#include "Parser.h"
#include "Patch.h"
#include "PointPair.h"

using namespace std;

//Global stuff to handle
char subDivType = 'u';
bool wireFrame = false;
bool flatShade = false;
bool hiddenLine = false;
float zoom = 1;
float rotateX = 0;
float rotateZ = 0;
float transX = 0;
float transY = 0;
float transZ = 0;
float step = 0;
float tau = 0;
int numPatches = 0;
Patch * myBezierPatch; //An array of all our patches
GLuint storedPN; //Stores the values computed during tessellation

class Viewport {
  public:
    int w, h; // width and height
};
Viewport	viewport;

// Reshape window if it's changed
void myReshape(int w, int h) {
  viewport.w = w;
  viewport.h = h;

  glViewport (0,0,viewport.w,viewport.h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
}

//Function to do things when the keyboard is pressed.
void myKybdHndlr(unsigned char key, int x, int y){
	if (key == 's') {
		if (flatShade == false) {
			flatShade = true;
		} else {
			flatShade = false;
		}
	}
	if (key == 'w') {
		if (wireFrame == false) {
			wireFrame = true;
		} else {
			wireFrame = false;
		}
	}
	if (key == 'h') {
		if (hiddenLine == false) {
			hiddenLine = true;
		} else {
			hiddenLine = false;
		}
	}
	if (key == '+') {
		zoom -= .1;
	}
	if (key == '-') {
		zoom += .1;
	}
	glutPostRedisplay();

}

//Function to handle arrow keys and shift keys
void SpecialInput(int key, int x, int y) {
	int mod = -99999999;
	switch(key) {
		case GLUT_KEY_DOWN:
			mod = glutGetModifiers();
			if (mod == GLUT_ACTIVE_SHIFT) {
				transZ += .1;
			} else {
				rotateX += .5;
			}
			break;
		case GLUT_KEY_UP:
			mod = glutGetModifiers();
			if (mod == GLUT_ACTIVE_SHIFT) {
				transZ -= .1;
			} else {
				rotateX -= .5;
			}
			break;
		case GLUT_KEY_LEFT:
			mod = glutGetModifiers();
			if (mod == GLUT_ACTIVE_SHIFT) {
				transX += .1;
			} else {
				rotateZ += .5;
			}
			break;
		case GLUT_KEY_RIGHT:
			mod = glutGetModifiers();
			if (mod == GLUT_ACTIVE_SHIFT) {
				transX -= .1;
			} else {
				rotateZ -= .5;
			}
			break;
}

glutPostRedisplay();
}

void tessellate(Patch* p, float u, float v, Point* x, Point* y) {
			Curve tmp1 = Curve(); //vcurve
			Curve tmp2 = Curve(); //ucurve
			Point tmpP1;
			Point tmpP2;
			Curve tmpC = Curve(*(p->cPts[0][0]),*(p->cPts[0][1]),*(p->cPts[0][2]),*(p->cPts[0][3]));
			Curve tmpC2 = Curve(*(p->cPts[0][0]),*(p->cPts[1][0]),*(p->cPts[2][0]),*(p->cPts[3][0]));
			tmpC.interpolate(u);
			tmpP1 = tmpC.getPointP();
			tmpC2.interpolate(v);
			tmpP2 = tmpC2.getPointP();
			tmp1.setPoint1(tmpP1);
			tmp2.setPoint1(tmpP2);
			tmpC = Curve(*(p->cPts[1][0]),*(p->cPts[1][1]),*(p->cPts[1][2]),*(p->cPts[1][3]));
			tmpC2 = Curve(*(p->cPts[0][1]),*(p->cPts[1][1]),*(p->cPts[2][1]),*(p->cPts[3][1]));
			tmpC.interpolate(u);
			tmpP1 = tmpC.getPointP();
			tmpC2.interpolate(v);
			tmpP2 = tmpC2.getPointP();
			tmp1.setPoint2(tmpP1);
			tmp2.setPoint2(tmpP2);
			tmpC = Curve(*(p->cPts[2][0]),*(p->cPts[2][1]),*(p->cPts[2][2]),*(p->cPts[2][3]));
			tmpC2 = Curve(*(p->cPts[0][2]),*(p->cPts[1][2]),*(p->cPts[2][2]),*(p->cPts[3][2]));
			tmpC.interpolate(u);
			tmpP1 = tmpC.getPointP();
			tmpC2.interpolate(v);
			tmpP2 = tmpC2.getPointP();
			tmp1.setPoint3(tmpP1);
			tmp2.setPoint3(tmpP2);
			tmpC = Curve(*(p->cPts[3][0]),*(p->cPts[3][1]),*(p->cPts[3][2]),*(p->cPts[3][3]));
			tmpC2 = Curve(*(p->cPts[0][3]),*(p->cPts[1][3]),*(p->cPts[2][3]),*(p->cPts[3][3]));
			tmpC.interpolate(u);
			tmpP1 = tmpC.getPointP();
			tmpC2.interpolate(v);
			tmpP2 = tmpC2.getPointP();
			tmp1.setPoint4(tmpP1);
			tmp2.setPoint4(tmpP2);
			Point pt;
			Point dxdv;
			Point dxdu;
			tmp1.interpolate(v);
			dxdv = tmp1.getPointS();
			tmp2.interpolate(u);
			pt = tmp2.getPointP();
			dxdu = tmp2.getPointS();
			*y = dxdu.getCrossProduct(dxdv);
			if (y->magnitude() == 0){
				Point tempXA, tempNA;
				if ((u + step/2 <= 1) && (v + step/2 <= 1)){
					tessellate(p, u + step/2, v + step/2, &tempXA, &tempNA);
				} else if ((u + step/2 <= 1) && (v + step/2 > 1)){
					tessellate(p, u + step/2, v - step/2, &tempXA, &tempNA);
				}else if ((u  + step/2 > 1) && (v + step/2 > 1)){
					tessellate(p, u - step/2, v - step/2, &tempXA, &tempNA);
				} else {
					tessellate(p, u - step/2, v + step/2, &tempXA, &tempNA);
				}
				*y = tempNA;
				}
				*y = y->normalize();
				*x = pt;
}

void initScene(){
  glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Clear to black, fully transparent
  glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_COLOR_MATERIAL);
  glDepthFunc(GL_LEQUAL);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  GLfloat amb[] = {0,0,0,0.1f};
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT, amb);

}
//vector<Point> vn1;
//vector<Point> vx1;
//vector<Point> vn2;
//vector<Point> vx2;
//vector<Point> vn3;
//vector<Point> vx3;
//vector<Point> vn4;
//vector<Point> vx4;

void subDivision(Patch* p){
	Point x1,x2,x3,x4,n1,n2,n3,n4;
	int i;
	int j;
	int k;
	int l;
	int quadNum = 1/step;
	step = float(1)/quadNum;
	for(i = 0; i <= quadNum; i++){
		float u = i*step;
		float uS = u + step;
		u = (u > 1) ? 1 : u;
		uS = (uS > 1) ? 1: uS;
		for (j = 0; j <= quadNum; j++){
			float v = j*step;
			float vS = v + step;
			v = (v > 1) ? 1 : v;
			vS = (vS > 1) ? 1: vS;
		    tessellate(p, u, v, &x1, &n1);
			tessellate(p, uS, v, &x2, &n2);
			tessellate(p, uS, vS, &x3, &n3);
			tessellate(p, u, vS, &x4, &n4);
			glNormal3f(n1.getX(),n1.getY(),n1.getZ());
			glVertex3f(x1.getX(),x1.getY(),x1.getZ());
			glNormal3f(n2.getX(),n2.getY(),n2.getZ());
			glVertex3f(x2.getX(),x2.getY(),x2.getZ());
			glNormal3f(n3.getX(),n3.getY(),n3.getZ());
			glVertex3f(x3.getX(),x3.getY(),x3.getZ());
			glNormal3f(n4.getX(),n4.getY(),n4.getZ());
			glVertex3f(x4.getX(),x4.getY(),x4.getZ());

//			vn1.push_back(n1);
//			vx1.push_back(x1);
//			vn2.push_back(n2);
//			vx2.push_back(x2);
//			vn3.push_back(n3);
//			vx3.push_back(x3);
//			vn4.push_back(n4);
//			vx4.push_back(x4);
		}
	}
}

// code adapted from lecture slides and https://code.google.com/p/l337h4xx0rz/source/browse/trunk/bez/glut_example.cpp?r=54

/*# given the control points of a bezier curve
# and a parametric value, return the curve 
# point and derivative*/
PointPair bezcurveinterp(Curve c, float u){
	/*# first, split each of the three segments
	# to form two new ones AB and BC*/
	Point A = c.getPoint1().multiplyScalar(1.0-u).addPoint(c.getPoint2().multiplyScalar(u));
	Point B = c.getPoint2().multiplyScalar(1.0-u).addPoint(c.getPoint3().multiplyScalar(u));
	Point C = c.getPoint3().multiplyScalar(1.0-u).addPoint(c.getPoint4().multiplyScalar(u));
	//now, split AB and BC to form a new segment DE
	Point D = A.multiplyScalar(1.0-u).addPoint(B.multiplyScalar(u));
	Point E = B.multiplyScalar(1.0-u).addPoint(C.multiplyScalar(u));
	/*finally, pick the right point on DE,
	this is the point on the curve*/
	Point p = D.multiplyScalar(1.0-u).addPoint(E.multiplyScalar(u));
	//compute derivative also
	Point dPdu = (E.subPoint(D).multiplyScalar(3));
	return PointPair(p, dPdu);
}

/*# given a control patch and (u,v) values, find 
# the surface point and normal*/
PointPair bezpatchinterp(Patch p, float u, float v){
	//# build control points for a Bezier curve in v
	Curve vcurve;
	vcurve.setPoint1(bezcurveinterp(p.getCurve1(), u).getPoint1());
	vcurve.setPoint2(bezcurveinterp(p.getCurve2(), u).getPoint1());
	vcurve.setPoint3(bezcurveinterp(p.getCurve3(), u).getPoint1());
	vcurve.setPoint4(bezcurveinterp(p.getCurve4(), u).getPoint1());
	//# build control points for a Bezier curve in u
	Curve ucurve;
	ucurve.setPoint1(bezcurveinterp(p.getVertCurve1(), v).getPoint1());
	ucurve.setPoint2(bezcurveinterp(p.getVertCurve2(), v).getPoint1());
	ucurve.setPoint3(bezcurveinterp(p.getVertCurve3(), v).getPoint1());
	ucurve.setPoint4(bezcurveinterp(p.getVertCurve4(), v).getPoint1());
	//# evaluate surface and derivative for u and v
	PointPair vinterp = bezcurveinterp(vcurve, v);
	PointPair uinterp = bezcurveinterp(ucurve, u);
	Point point = uinterp.getPoint1();
	Point dPdv = vinterp.getPoint2();
	Point dPdu = uinterp.getPoint2();
	//# take cross product of partials to find normal
	Point n = dPdu.getCrossProduct(dPdv);
	//cout << "Normals " << n.getX() << " " << n.getY() << " " << n.getZ() << endl;
	n = n.normalize();
	return PointPair(point, n);
}

	//given a patch, perform uniform subdivision
void subdividepatch(Patch p, float step){
/*# compute how many subdivisions there 
# are for this step size*/
	//float numdiv = ((1 + 0.00001) / step);
	//# for each parametric value of u
	double epsilon = 0.05;        
    double numdiv = (1.0 + epsilon) / step;
    const int n = (int)numdiv;
    double equalstep = 1.0/n;
	float u;
	float v;
	Point ps [100][100];
	Point ns [100][100];
	for (int iu = 0; iu <= n; iu ++){
		u = iu * equalstep;
		//# for each parametric value of v
		for (int iv = 0; iv <= n; iv ++){
			v = iv * equalstep;
			//#evaluate surface
			PointPair pair = bezpatchinterp(p, u, v);
			ps[iu][iv] = pair.getPoint1();
			ns[iu][iv] = pair.getPoint2();
			//savesurfacepointandnormal(p,n)
		}
	}
	for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            glBegin(GL_QUADS);
            
            glNormal3f(ns[i][j].getX(),ns[i][j].getY(),ns[i][j].getZ());
            glVertex3f(ps[i][j].getX(),ps[i][j].getY(),ps[i][j].getZ());
            
            glNormal3f(ns[i+1][j].getX(),ns[i+1][j].getY(),ns[i+1][j].getZ());
            glVertex3f(ps[i+1][j].getX(),ps[i+1][j].getY(),ps[i+1][j].getZ());
            
            glNormal3f(ns[i+1][j+1].getX(),ns[i+1][j+1].getY(),ns[i+1][j+1].getZ());
            glVertex3f(ps[i+1][j+1].getX(),ps[i+1][j+1].getY(),ps[i+1][j+1].getZ()); 
            
            glNormal3f(ns[i][j+1].getX(),ns[i][j+1].getY(),ns[i][j+1].getZ());           
            glVertex3f(ps[i][j+1].getX(),ps[i][j+1].getY(),ps[i][j+1].getZ());
            
            glEnd();
            
        }
    }
}

void adaptiveTessellation (Patch patch, double triangle[3][2]) {
        // get the u,v of triangles vertices
        double u1 = triangle[0][0]; 
		double u2 = triangle[1][0];
		double u3 = triangle[2][0];
		double v1 = triangle[0][1]; 
		double v2 = triangle[1][1]; 
		double v3 = triangle[2][1];
        
        // midpoints are in form of {midpoint u, midpoint v}
        double midpoint_12[2] = {0.5*(u1+u2), 0.5*(v1+v2)};
        double midpoint_23[2] = {0.5*(u2+u3), 0.5*(v2+v3)};
        double midpoint_31[2] = {0.5*(u3+u1), 0.5*(v3+v1)};
		PointPair pair;
        
        // Interpolate Midpoints
		Point mpoint_12, normal_12;
		pair = bezpatchinterp(patch, midpoint_12[0], midpoint_12[1]);
		mpoint_12 = pair.getPoint1();
		normal_12 = pair.getPoint2();
        
		Point mpoint_23, normal_23;
		pair = bezpatchinterp(patch, midpoint_23[0], midpoint_23[1]);
		mpoint_23 = pair.getPoint1();
		normal_23 = pair.getPoint2();
        
		Point mpoint_31, normal_31;
		pair = bezpatchinterp(patch, midpoint_31[0], midpoint_31[1]);
		mpoint_31 = pair.getPoint1();
		normal_31 = pair.getPoint2();
        
        // Interpolate Endpoints
		Point point1, normal1;
        pair = bezpatchinterp(patch, u1, v1);
		point1 = pair.getPoint1();
		normal1 = pair.getPoint2();

		Point point2, normal2;
        pair = bezpatchinterp(patch, u2, v2);
		point2 = pair.getPoint1();
		normal2 = pair.getPoint2();

		Point point3, normal3;
        pair = bezpatchinterp(patch, u3, v3);
		point3 = pair.getPoint1();
		normal3 = pair.getPoint2();
        
        // Get Midpoints of Interpolated Endpoints
		Point interpmidpoint_12 = point1.addPoint(point2).multiplyScalar(0.5);
		Point interpmidpoint_23 = point2.addPoint(point3).multiplyScalar(0.5);
		Point interpmidpoint_31 = point3.addPoint(point1).multiplyScalar(0.5);
        
        // Get Error
		bool e_12 = (interpmidpoint_12.subPoint(mpoint_12).magnitude()) > tau;
		bool e_23 = (interpmidpoint_23.subPoint(mpoint_23).magnitude()) > tau;
		bool e_31 = (interpmidpoint_31.subPoint(mpoint_31).magnitude()) > tau;        
        
        if (!e_12 && !e_23 && !e_31) {
                glBegin(GL_TRIANGLES);
                /*cout << "Normals" << normal1.getX() << " " << normal1.getY() << " " << normal1.getZ() << endl;
				cout << "Points1" << point1.getX() << " " << point1.getY() << " " << point1.getZ() << endl;
				cout << "Points2" << point2.getX() << " " << point2.getY() << " " << point2.getZ() << endl;
				cout << "Points3" << point3.getX() << " " << point3.getY() << " " << point3.getZ() << endl;*/
                glNormal3f(normal1.getX(), normal1.getY(), normal1.getZ());
                glVertex3f(point1.getX(), point1.getY(), point1.getZ());
                
                glNormal3f(normal2.getX(), normal2.getY(), normal2.getZ());
                glVertex3f(point2.getX(), point2.getY(), point2.getZ());
                
                glNormal3f(normal3.getX(), normal3.getY(), normal3.getZ());
                glVertex3f(point3.getX(), point3.getY(), point3.getZ());

                glEnd();
        }
        else if (e_12 && !e_23 && !e_31) {
                double newTriangle1[3][2] = {{midpoint_12[0], midpoint_12[1]}, {u3,v3}, {u1,v1}};
                adaptiveTessellation(patch, newTriangle1);
                
                double newTriangle2[3][2] = {{midpoint_12[0], midpoint_12[1]}, {u2,v2}, {u3,v3}};
                adaptiveTessellation(patch, newTriangle2);
        }
        else if (!e_12 && e_23 && !e_31) {
                double newTriangle1[3][2] = {{midpoint_23[0], midpoint_23[1]}, {u3,v3}, {u1,v1}};
                adaptiveTessellation(patch, newTriangle1);
                
                double newTriangle2[3][2] = {{midpoint_23[0], midpoint_23[1]}, {u1,v1}, {u2,v2}};
                adaptiveTessellation(patch, newTriangle2);
        }
        else if (!e_12 && !e_23 && e_31) {
                double newTriangle1[3][2] = {{midpoint_31[0], midpoint_31[1]}, {u1,v1}, {u2,v2}};
                adaptiveTessellation(patch, newTriangle1);
                
                double newTriangle2[3][2] = {{midpoint_31[0], midpoint_31[1]}, {u2,v2}, {u3,v3}};
                adaptiveTessellation(patch, newTriangle2);
        }
        else if (e_12 && e_23 && !e_31) {
                double newTriangle1[3][2] = {{midpoint_23[0], midpoint_23[1]}, {midpoint_12[0],midpoint_12[1]}, {u2,v2}};
                adaptiveTessellation(patch, newTriangle1);
                
                double newTriangle2[3][2] = {{midpoint_23[0], midpoint_23[1]}, {u1,v1}, {midpoint_12[0],midpoint_12[1]}};
                adaptiveTessellation(patch, newTriangle2);
                
                double newTriangle3[3][2] = {{midpoint_23[0], midpoint_23[1]}, {u3,v3}, {u1,v1}};
                adaptiveTessellation(patch, newTriangle3);
        }
        else if (!e_12 && e_23 && e_31) {
                double newTriangle1[3][2] = {{midpoint_31[0], midpoint_31[1]}, {midpoint_23[0],midpoint_23[1]}, {u3,v3}};
                adaptiveTessellation(patch, newTriangle1);
                
                double newTriangle2[3][2] = {{midpoint_31[0], midpoint_31[1]}, {u2,v2}, {midpoint_23[0],midpoint_23[1]}};
                adaptiveTessellation(patch, newTriangle2);
                
                double newTriangle3[3][2] = {{midpoint_31[0], midpoint_31[1]}, {u1,v1}, {u2,v2}};
                adaptiveTessellation(patch, newTriangle3);
        }
        else if (e_12 && !e_23 && e_31) {
                double newTriangle1[3][2] = {{midpoint_12[0], midpoint_12[1]}, {midpoint_31[0],midpoint_31[1]}, {u1,v1}};
                adaptiveTessellation(patch, newTriangle1);
                
                double newTriangle2[3][2] = {{midpoint_12[0], midpoint_12[1]}, {u3,v3}, {midpoint_31[0],midpoint_31[1]}};
                adaptiveTessellation(patch, newTriangle2);
                
                double newTriangle3[3][2] = {{midpoint_12[0], midpoint_12[1]}, {u2,v2}, {u3,v3}};
                adaptiveTessellation(patch, newTriangle3);
        }
        else if (e_12 && e_23 && e_31) {
                double newTriangle1[3][2] = {{midpoint_31[0], midpoint_31[1]}, {u1,v1}, {midpoint_12[0],midpoint_12[1]}};
                adaptiveTessellation(patch, newTriangle1);
                
                double newTriangle2[3][2] = {{midpoint_31[0], midpoint_31[1]}, {midpoint_23[0],midpoint_23[1]}, {u3,v3}};
                adaptiveTessellation(patch, newTriangle2);
                
                double newTriangle3[3][2] = {{midpoint_12[0], midpoint_12[1]}, {u2,v2}, {midpoint_23[0],midpoint_23[1]}};
                adaptiveTessellation(patch, newTriangle3);
                
                double newTriangle4[3][2] = {{midpoint_31[0], midpoint_31[1]}, {midpoint_12[0],midpoint_12[1]}, {midpoint_23[0],midpoint_23[1]}};
                adaptiveTessellation(patch, newTriangle4);
        }
        else {
                cout << "ERROR!" << endl;
        }
}

// Draw stuff
void myDisplay() {
	glColor3f(0.0f,0.0f,1.0f);
  //clear color and depth buffer 
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);                // clear the color buffer (sets everything to black)

 // glMatrixMode(GL_PROJECTION);
  //glMatrixMode(GL_MODELVIEW);                  // indicate we are specifying camera transformations
 // glLoadIdentity();                            // make sure transformation is "zero'd"
 // gluLookAt (0.0, 10.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);




  //----------------------- code to draw objects --------------------------
  // Rectangle Code
  //glColor3f(red component, green component, blue component);
                    // setting the color to pure blue 90% for the rect

//  glBegin(GL_TRIANGLES);                         // draw rectangle
//  //glVertex3f(x val, y val, z val (won't change the point because of the projection type));
//  glVertex3f(-1.0f,-0.25f,0.0f);//triangle one first vertex
//  glVertex3f(-0.5f,-0.25f,0.0f);//triangle one second vertex
//  glVertex3f(-0.75f,0.25f,0.0f);//triangle one third vertex
//  //drawing a new triangle
//  glVertex3f(0.5f,-0.25f,0.0f);//triangle two first vertex
//  glVertex3f(1.0f,-0.25f,0.0f);//triangle two second vertex
//  glVertex3f(0.75f,0.25f,0.0f);//triangle two third vertex




glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluPerspective (45*zoom, viewport.w/viewport.h, 0.01f, 200.0f);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
gluLookAt (0.0, 10.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
if(hiddenLine == true) {
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}
glPushMatrix();
glTranslatef(-transX, transY, transZ);
glRotatef(rotateX, 1.0,0.0,0.0); //rotate about the x axis
glRotatef(rotateZ, 0.0,0.0,1.0); //rotate about the z axis
if(hiddenLine == true) {
	#pragma omp parallel for
	for (int i = 0; i < numPatches; i++) {
		if (subDivType == 'a'){
			double triangle1[3][2] = {{0,0},{1,0},{1,1}};
            adaptiveTessellation(myBezierPatch[i], triangle1);
                        
            double triangle2[3][2] = {{0,0},{1,1},{0,1}};
            adaptiveTessellation(myBezierPatch[i], triangle2);
		}
		else{
			subdividepatch(myBezierPatch[i], step);
		}
	}
	glPopMatrix();
//	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0f,0.0f,0.0f);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glPushMatrix();
	glTranslatef(-transX, transY, transZ);
	glRotatef(rotateX, 1.0,0.0,0.0);
	glRotatef(rotateZ, 0.0,0.0,1.0);
}
if(hiddenLine == false) {
	if(wireFrame == true){
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	} else {
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}
}
if(flatShade == true){
	glShadeModel(GL_FLAT);
} else{
	glShadeModel(GL_SMOOTH);
}

#pragma omp parallel for
for (int i = 0; i < numPatches; i++) {
	if (subDivType == 'a'){
		double triangle1[3][2] = {{0,0},{1,0},{1,1}};
        adaptiveTessellation(myBezierPatch[i], triangle1);
                        
        double triangle2[3][2] = {{0,0},{1,1},{0,1}};
        adaptiveTessellation(myBezierPatch[i], triangle2);
	}
	else{
		subdividepatch(myBezierPatch[i], step);
	}
}

//for (int i = 0; i < vn1.size(); i++) {
//	glNormal3f(vn1[i].getX(),vn1[i].getY(),vn1[i].getZ());
//	glVertex3f(vx1[i].getX(),vx1[i].getY(),vx1[i].getZ());
//	glNormal3f(vn2[i].getX(),vn2[i].getY(),vn2[i].getZ());
//	glVertex3f(vx2[i].getX(),vx2[i].getY(),vx2[i].getZ());
//	glNormal3f(vn3[i].getX(),vn3[i].getY(),vn3[i].getZ());
//	glVertex3f(vx3[i].getX(),vx3[i].getY(),vx3[i].getZ());
//	glNormal3f(vn4[i].getX(),vn4[i].getY(),vn4[i].getZ());
//	glVertex3f(vx4[i].getX(),vx4[i].getY(),vx4[i].getZ());
//}

  glFlush();
  glutSwapBuffers();
}

int main(int argc, char *argv[]){
	if (argc > 1){
		std::string file = argv[1];
		step = atof(argv[2]);
		tau = atof(argv[2]);
		if (argc == 4) {
			std::string divType = argv[3];
			if (divType == "-a") {
				subDivType = 'a';
			};
		}
		Parser p;
		myBezierPatch = p.loadBez(file);
		numPatches = p.getNumPatches();
		storedPN = glGenLists(numPatches);
		glutInit(&argc, argv);

		//This tells glut to use a double-buffered window with red, green, and blue channels and depth
		glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

		// Initalize theviewport size
		viewport.w = 400;
		viewport.h = 400;

		//The size and position of the window
		glutInitWindowSize(viewport.w, viewport.h);
		glutInitWindowPosition(0,0);
		glutCreateWindow("Assignment 3");

		initScene(); 

		glutDisplayFunc(myDisplay);				// function to run when its time to draw something
		glutReshapeFunc(myReshape);				// function to run when the window gets resized
		glutKeyboardFunc(myKybdHndlr);			// function to handle keyboard inputs
		glutSpecialFunc(SpecialInput);			// function to handle special keyboard inputs

		glutMainLoop();							// infinite loop that will keep drawing and resizing

	}
	else{
		std::cout<<"Please input the name of the file."<<endl;
	}

	return 0;
}
